/* 
 * logDataVSPrior is a function to calculate 
 * the accumulation from ABS of two groups of complex data
 * *************************************************************************/

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <immintrin.h>
#include <complex>
#include <chrono>
#include <omp.h> 
#include <mpi.h>
#define db double
using namespace std;

typedef chrono::high_resolution_clock Clock;

const int m=1638400;	// DO NOT CHANGE!!
const int K=100000;	// DO NOT CHANGE!!
typedef double Complex;
float logDataVSPrior(const float* dat, const float* pri,  const float* ctf, const float* sigRcp,const int num, const float disturb0)
{
    register float result = 0.0;

    register float *disturb = new float[16];
    register int i;
    for(i = 0;i < 16 ;++i) *(disturb+i) = disturb0;
    register __m512 s1,s2,s3,s4,s5;
    s5 = _mm512_loadu_ps(disturb);
    delete[] disturb;
    register int block = num/16 , res=num%16;
    #pragma omp parallel for reduction(+:result)
    for(i = 0;i < block; ++i,dat+=16,pri+=16,ctf+=16,sigRcp+=16){
    	s1 = _mm512_loadu_ps(dat);
    	s2 = _mm512_loadu_ps(pri);
    	s3 = _mm512_loadu_ps(ctf);
   		s4 = _mm512_loadu_ps(sigRcp); 
   		s2 = _mm512_mul_ps(s2,s3);
   		s2 = _mm512_mul_ps(s2,s5);
   		s1 = _mm512_sub_ps(s1,s2);
    	s1 = _mm512_mul_ps(s1,s1);
    	s1 = _mm512_mul_ps(s1,s4);
    	result += _mm512_reduce_add_ps(s1);
    }
	for(i = block*16 ; i < num ; ++i){
    	result += ( (*(dat+i)) - (*(pri+i)) * (*(ctf+i))*disturb0 ) * ( (*(dat+i)) - (*(pri+i)) * (*(ctf+i))*disturb0 )* (*(sigRcp+i));
	}
    return result;
}


int main ( int argc, char *argv[] )
{ 
    register float *dat = new float[2*m];
    register float *pri = new float[2*m];

    register float *ctf = new float[2*m];
    register float *sigRcp = new float[2*m];
    register float *disturb = new float[K];
	register float *result = new float[K];
	 
    /***************************
     * Read data from input.dat
     * *************************/
    ifstream fin;

    fin.open("input.dat");
    if(!fin.is_open())
    {
        cout << "Error opening file input.dat" << endl;
        exit(1);
    }
    register int i=0;
    while( !fin.eof() ) 
    {
        fin >> dat[2*i] >> dat[2*i+1]>> pri[2*i] >> pri[2*i+1] >> ctf[2*i] >> sigRcp[2*i];
		ctf[2*i+1] = ctf[2*i];
		sigRcp[2*i+1] = sigRcp[2*i];
        i++;
        if(i == m) break;
    }
    fin.close();

    fin.open("K.dat");
    if(!fin.is_open())
    {
	cout << "Error opening file K.dat" << endl;
	exit(1);
    }
    i=0;
    while( !fin.eof() )
    {
	fin >> disturb[i];
	i++;
	if(i == K) break;
    }
    fin.close();

    /***************************
     * main computation is here
     * ************************/
    auto startTime = Clock::now(); 

    register int res,block,num,myid;
	MPI_Init(&argc, &argv);
	
	MPI_Comm_size(MPI_COMM_WORLD,&num);
	MPI_Comm_rank(MPI_COMM_WORLD,&myid);
	res = (2*m)%num , block = (2*m)/num;
	register float *local_dat,*local_pri,*local_ctf,*local_sigRcp;
	register int *count,*disp;
	local_dat = new float[(2*m)/num+(myid<res)];
	local_pri = new float[(2*m)/num+(myid<res)];
	local_ctf = new float[(2*m)/num+(myid<res)];
	local_sigRcp = new float[(2*m)/num+(myid<res)];
	count = new int [num];
	disp = new int [num];
	for(i = 0;i<num;++i) count[i] = block + (i<res);
	for(disp[0]=0,i = 1;i<num;++i) disp[i] = disp[i-1] + count[i];
	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Scatterv(dat, count, disp, MPI_FLOAT, local_dat, count[myid], MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Scatterv(pri, count, disp, MPI_FLOAT, local_pri, count[myid], MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Scatterv(ctf, count, disp, MPI_FLOAT, local_ctf, count[myid], MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Scatterv(sigRcp, count, disp, MPI_FLOAT, local_sigRcp, count[myid], MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	for(register unsigned int t = 0; t < K; ++t)
	{
		register float local_result = logDataVSPrior(local_dat, local_pri, local_ctf, local_sigRcp, (2*m)/num+(myid<res), disturb[t]);
		MPI_Reduce(&local_result, result+t, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
	}
	
    delete[] local_dat;
    delete[] local_pri;
    delete[] local_ctf;
    delete[] local_sigRcp;
    delete[] count;
    delete[] disp;
	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();
	if(myid == 0){
		
		FILE *fp; 
    	fp = fopen("result.dat","w");
    	if(fp==NULL){
            cout << "Error opening file for result" << endl;
            exit(1);
    	}
		
	    
		for(register int t = 0; t < K; ++t){
		    fprintf(fp,"%d: %g\n",t+1,*(result+t));
		}
		fclose(fp);	      
	
	    auto endTime = Clock::now(); 
	
	    auto compTime = chrono::duration_cast<chrono::microseconds>(endTime - startTime);
	    cout << "Computing time=" << compTime.count() << " microseconds" << endl;
	    
	    delete[] dat;
	    delete[] pri;
	    delete[] ctf;
	    delete[] sigRcp;
	    delete[] disturb; 
	}
	return EXIT_SUCCESS;
}


